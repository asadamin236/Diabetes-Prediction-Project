import numpy as np
import pandas as pd
from flask import Flask, request, render_template
import joblib

app = Flask(__name__)

model = joblib.load("Model_prediction.pkl")

df = pd.DataFrame()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    global df

    input_features = [float(x) for x in request.form.values()]
    output = input_features[0]

    # Validate input hours
    if output == 1:
        prediction_result = "Positive"
    elif output == 0:
        prediction_result = "Negative"
    else:
        # Perform the actual prediction using the loaded model
        prediction_result = model.predict([output])

    return render_template('index.html', prediction_text=f"The Predicted Result is {prediction_result}")

if __name__ == "__main__":
    app.run(debug = True)
    